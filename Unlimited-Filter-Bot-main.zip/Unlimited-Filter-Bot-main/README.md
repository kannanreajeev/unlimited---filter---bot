# Unlimited Filter Bot

<p align="center">
  <a href="https://www.python.org">
    <img src="http://ForTheBadge.com/images/badges/made-with-python.svg">

  </a>
</p>
<p align="center">
  <a href="https://github.com/MRK-YT/Unlimited-Filter-Bot/stargazers">
    <img src="https://img.shields.io/github/stars/MRK-YT/Unlimited-Filter-Bot?style=social">

  </a>
  
  <a href="https://github.com/MRK-YT/Unlimited-Filter-Bot/fork">
    <img src="https://img.shields.io/github/forks/MRK-YT/Unlimited-Filter-Bot?label=Fork&style=social">

  </a>  
</p>

[![TroJanz](https://img.shields.io/badge/Connect-Creater-skyblue?style=for-the-badge&logo=telegram)](https://telegram.dog/Mo_Tech_YT)  
ㅤㅤㅤㅤㅤㅤㅤ  
[![MoTechYT](https://img.shields.io/badge/MoTechYT-Support-red?style=flat&logo=telegram)](https://telegram.dog/Mo_Tech_Channel)  [![TroJanz](https://img.shields.io/badge/Youtube-channel-red?style=flat&logo=Youtube)](https://youtube.com/channel/UCmGBpXoM-OEm-FacOccVKgQ)  ㅤㅤㅤㅤㅤㅤ  

[![MoTechYT](https://img.shields.io/badge/Connect-Telegram-red?style=flat&logo=telegram)](https://telegram.dog/Mrk_yt)


### Deploy

[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy?template=https://github.com/MRK-YT/Unlimited-Filter-Bot)

### Features
* Nearly unlimited filters
* Supports all type of filters(Including Alert Button Filter).
* Can save button filters directly (Rose Bot Feature)
* Supports multiple PM connections
* And all other features of a Filter Bot :D


## Configs

APP.ID & API.HASH :-
 [![MoTechYT](https://img.shields.io/badge/Click-Here-red?style=flat&logo=telegram)](https://telegram.dog/usetgxbot) or [![MoTechYT](https://img.shields.io/badge/Click-Here-red?style=flat&logo=Google)](https://my.telegram.org/auth)

AUTH_USERS :- [![MoTechYT](https://img.shields.io/badge/Click-Here-red?style=flat&logo=telegram)](https://telegram.dog/MissRose_bot)

DATABASE_NAME :- Cluster0

DATABASE_URI :- [![MoTechYT](https://img.shields.io/badge/Click-Here-red?style=flat&logo=mongodb)](https://www.mongodb.com/cloud/atlas/lp/try2-in?utm_source=google&utm_campaign=gs_apac_india_search_core_brand_atlas_mobile&utm_term=mongodb&utm_medium=cpc_paid_search&utm_ad=e&utm_ad_campaign_id=12564980858&gclid=CjwKCAjwx6WDBhBQEiwA_dP8rcft9hLV9WxyBV4c1VMZfdmMVi9mifPxBPVbZDnhGBbQhs8rwqXQ8xoC6U8QAvD_BwE)

HEROKU_API_KEY :- [![MoTechYT](https://img.shields.io/badge/Click-Here-red?style=flat&logo=heroku)](https://dashboard.heroku.com/account)

TG BOT TOKEN :- [![MoTechYT](https://img.shields.io/badge/Click-Here-red?style=flat&logo=telegram)](https://telegram.dog/BotFather) 
